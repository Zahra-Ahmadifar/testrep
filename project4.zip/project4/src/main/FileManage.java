package main;

/**
 * Created by Asus on 2/16/2021.
 */

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

public class FileManage {
    private static String debtorDepositNumber = "1.10.100.1";
    private static String debtorAmount = "10000";
    private static int employeenum = 100;
    private String creditorAmount = String.valueOf(Integer.parseInt(debtorAmount) / employeenum);
    PaymentInfo p = new PaymentInfo();


    public void paymentFile() {

        try {
            File file = new File("F:\\project4\\PaymentFiles\\PaymentFile.txt");
            if (!file.exists()) {
                file.createNewFile();
                System.out.println("creating new file");
            } else {
                System.out.println("file already exists");

            }
            String debtor = "debtor\t" + debtorDepositNumber + "\t" + debtorAmount;

            String[] staffs = new String[employeenum];
            for (int i = 0; i < employeenum; i++) {

                String staffDepositNumber = String.format("1.20.100.%d ", i + 1);

                staffs[i] = "creditor\t" + staffDepositNumber + "\t" + creditorAmount;
            }
            BufferedWriter bw = new BufferedWriter(new FileWriter("F:\\project4\\PaymentFiles\\PaymentFile.txt"));
            bw.write(debtor);
            bw.newLine();
            for (int i = 0; i < employeenum; i++) {
                bw.write(staffs[i]);
                bw.newLine();
            }
            bw.close();

        } catch (IOException e) {

            e.printStackTrace();
        }
    }

    public void stockFile() {
        try {
            File file = new File("F:\\project4\\PaymentFiles\\StockFile.txt");
            if (!file.exists()) {
                file.createNewFile();
                System.out.println("creating new file");
            } else {
                System.out.println("file already exists");

            }
            BufferedWriter bw = new BufferedWriter(new FileWriter("F:\\project4\\PaymentFiles\\StockFile.txt"));
            bw.write(debtorDepositNumber + "\t" + debtorAmount);
            bw.newLine();
            bw.close();
            System.out.println("finish writing initial amount of debtor");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void transactionFile() {
        try {
            File file = new File("F:\\project4\\PaymentFiles\\TransactionFile.txt");
            if (!file.exists()) {
                file.createNewFile();
                System.out.println("creating new file");
            } else {
                System.out.println("file already exists");

            }
        } catch (IOException e) {

            e.printStackTrace();
        }

    }

    public void writeStockFile(List<PaymentInfo> paymentList) {

        try {
            File file = new File("F:\\project4\\PaymentFiles\\StockFile.txt");
            if (!file.exists()) {
                file.createNewFile();
                System.out.println("creating new file");
            } else {
                System.out.println("updating Stockfile ");

            }
            BufferedWriter bw = new BufferedWriter(new FileWriter("F:\\project4\\PaymentFiles\\StockFile.txt", true));

            for (PaymentInfo payment : paymentList) {
                bw.write(payment.getDepositNumber() + "\t" + payment.getAmount());
                bw.newLine();
            }

            bw.close();

            System.out.println("finish writing to Stockfile");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void writeTransactionFile() {

        try {
            File file = new File("F:\\project4\\PaymentFiles\\TransactionFile.txt");
            if (!file.exists()) {
                file.createNewFile();
                System.out.println("creating new file");
            } else {
                System.out.println("updating Transactionfile");

            }
            BufferedWriter bw = new BufferedWriter(new FileWriter("F:\\project4\\PaymentFiles\\TransactionFile.txt", true));

            for (int i = 0; i < employeenum; i++) {

                String staffDepositNumber = String.format("1.20.100.%d ", i + 1);

                bw.write(debtorDepositNumber + "\t" + staffDepositNumber + "\t" + creditorAmount);
                bw.newLine();


            }
            bw.close();
            System.out.println("finish writing to Transactionfile");
        } catch (IOException e) {

            e.printStackTrace();
        }
    }


}
