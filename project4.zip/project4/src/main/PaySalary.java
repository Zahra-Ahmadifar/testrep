package main;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Asus on 2/16/2021.
 */
public class PaySalary {
    private String debtorDepositNumber;
    private int totalPaymentRecord;
    List<PaymentInfo> paymentList = new ArrayList<>();
    int debtAmount;
    int totalAmount;
    FileManage file = new FileManage();

    private static final String paymentPath = "F:\\project4\\PaymentFiles\\PaymentFile.txt";

    public void pay() {

        file.paymentFile();
        file.stockFile();
        file.transactionFile();
        cretePaymentlist();

    }


    private void cretePaymentlist() {
        List<String> paymentData;
        try (BufferedReader br = new BufferedReader(new FileReader(paymentPath))) {
            String sCurrentLine;
            while ((sCurrentLine = br.readLine()) != null) {

                PaymentInfo p = new PaymentInfo();
                String[] data = sCurrentLine.split("\t");
                p.setRole(data[0]);
                p.setDepositNumber(data[1]);
                p.setAmount(data[2]);
                if (p.getRole().equals("debtor")) {
                    debtAmount = (Integer.parseInt(p.getAmount()));
                    debtorDepositNumber = p.getDepositNumber();
                } else {
                    totalAmount += Integer.parseInt(p.getAmount());
                }
                paymentList.add(p);

            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        totalPaymentRecord = paymentList.size();
        checkPayment(debtAmount, totalAmount);

    }


    private void checkPayment(int debtAmount, int totalAmount) {

        if (totalAmount <= debtAmount) {
            doPayment(debtAmount, totalAmount);
        } else {
            System.out.println("debtor amount is not enough for payment");
        }
    }


    private void doPayment(int debtAmount, int totalAmount) {
        for (PaymentInfo p : paymentList) {
            if (p.getRole().equals("debtor")) {
                p.setAmount(String.valueOf(debtAmount - totalAmount));
            }
        }
        file.writeStockFile(paymentList);
        file.writeTransactionFile();

    }
}
