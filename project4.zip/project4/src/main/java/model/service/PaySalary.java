package model.service;

import exceptionhandling.FialFileWritingException;
import model.entity.PaymentFileVO;
import model.entity.PaymentInfo;
import model.entity.StockFileVO;
import org.apache.log4j.Logger;

import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Created by Asus on 2/16/2021.
 */
public class PaySalary {
    private String debtorDepositNumber;
    private int totalPaymentRecord;
    List<PaymentFileVO> paymentList = new ArrayList<>();
    ExecutorService executor = Executors.newFixedThreadPool(5);
    BigDecimal debtAmount = BigDecimal.ZERO;
    BigDecimal totalAmount = BigDecimal.ZERO;
    private int threadNumber;
    private int recordNumberPerThread = 25;
    List<StockFileVO> stockList = new ArrayList<>();
    List<String> stockdata = new ArrayList<>();


    private Path paymentPath;
    private Path stockPath;

    static Logger logger = Logger.getLogger(PaySalary.class);
    FileManage file = new FileManage();


    public void pay() {

        paymentPath = file.createPaymentFile();
        stockPath = file.createStockFile();

        createPaymentlist();
    }


    private void createPaymentlist() {

        List<String> paymentData = readFile(paymentPath);
        for (String payments : paymentData) {
            PaymentFileVO payment = new PaymentFileVO();
            String[] data = payments.split("\t");
            if (!data[0].equals("debtor")) {
                payment.depositType = false;
            }
            payment.setDepositNumber(data[1]);
            payment.setAmount(new BigDecimal(data[2]));
            calculateTotalamount(payment);
            paymentList.add(payment);
        }
        totalPaymentRecord = paymentList.size();
        checkStockfile();
    }


    private List readFile(Path filePath) {
        List<String> paymentData;
        try {
            paymentData = Files.readAllLines(filePath);
        } catch (IOException e) {
            throw new FialFileWritingException("fail reading the payment value file.");
        }
        return paymentData;
    }


    private void calculateTotalamount(PaymentFileVO payment) {
        if (!payment.depositType) {
            totalAmount = totalAmount.add(payment.getAmount());
        } else {
            debtAmount = debtAmount.add(payment.getAmount());
            debtorDepositNumber = payment.getDepositNumber();
        }
    }


    private void doPayment() {
        int fromIndex = 0;
        threadNumber = totalPaymentRecord / recordNumberPerThread;

        for (int i = 0; i < threadNumber; i++) {
            int toIndex = fromIndex + (recordNumberPerThread);
            List<PaymentInfo> paymentListPerThread = new ArrayList<>(paymentList.subList(fromIndex, toIndex));
            List<PaymentInfo> depositList = new ArrayList<>(stockList);
            fromIndex += recordNumberPerThread;
            Runnable runnable = new PaymentOperation(stockdata, paymentListPerThread, totalAmount, debtorDepositNumber, depositList, stockPath);
            executor.execute(runnable);
        }
        executor.shutdown();
    }


    private void checkStockfile() {
        createStockList();
        BigDecimal debtorlastAmount = stockList.get(0).getAmount();
        if (debtorlastAmount.compareTo(totalAmount) != -1)
            doPayment();
        else {
            logger.info("debtor amount is not enough for payment");
        }
    }


    private void createStockList() {

        List<String> paymentData = readFile(stockPath);
        for (String src : paymentData) {
            StockFileVO payment = new StockFileVO();
            String[] data = src.split("\t");
            payment.setDepositNumber(data[0]);
            payment.setAmount(new BigDecimal(data[1]));
            stockList.add(payment);
        }
    }
}