package model.service;

/**
 * Created by Asus on 2/16/2021.
 */


import model.entity.PaymentFileVO;
import model.entity.PaymentInfo;
import model.entity.StockFileVO;
import model.entity.TransactionFileVO;
import org.apache.log4j.Logger;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.List;

public class FileManage {
    private static String debtorDepositNumber = "1.10.100.1";
    private static String debtorAmount = "99000";
    private static int employeenum = 99;
    private String creditorAmount = String.valueOf(1000 / employeenum);

    PaymentInfo p = new PaymentInfo();

    static Logger logger = Logger.getLogger(FileManage.class);

    public Path createPaymentFile() {

        String debtor = "debtor\t" + debtorDepositNumber + "\t" + debtorAmount;

        String[] staffs = new String[employeenum];
        for (int i = 0; i < employeenum; i++) {

            String staffDepositNumber = String.format("1.20.100.%d ", i + 1);

            staffs[i] = "creditor\t" + staffDepositNumber + "\t" + creditorAmount;
        }
        Path paymentPath = Paths.get("PaymentFiles/PaymentFile.txt");
        try {

            if (!Files.exists(paymentPath)) {

                Files.createFile(paymentPath);
                PaymentFileVO.toString(paymentPath, debtor, staffs, employeenum);


            } else {
                logger.info("payment file already exists.");
            }

        } catch (FileNotFoundException e) {
            logger.error("payment file not found");
        } catch (IOException e) {
            System.out.println(e.getClass() + "\t" + e.getMessage());
        }
        return paymentPath;
    }

    public Path createStockFile() {

        Path stockPath = Paths.get("PaymentFiles/StockFile.txt");
        try {

            if (!Files.exists(stockPath)) {

                Files.createFile(stockPath);
                String bank = debtorDepositNumber + "\t" + debtorAmount;
                Files.write(stockPath, bank.getBytes(), StandardOpenOption.APPEND);
                Files.write(stockPath, System.getProperty("line.separator").getBytes(), StandardOpenOption.APPEND);

            } else {
                logger.info("stock file already exists.");
            }

        } catch (FileNotFoundException e) {
            logger.error("stock file not found");
        } catch (IOException e) {
            logger.error(e.getClass() + "\t" + e.getMessage());

        }
        return stockPath;
    }

    public Path createTransactionFile() {

        Path transactionPath = Paths.get("PaymentFiles/TransactionFile.txt");
        try {

            if (!Files.exists(transactionPath)) {

                Files.createFile(transactionPath);
            } else {
                logger.info("transaction file updating.");
            }

        } catch (FileNotFoundException e) {
            logger.error("transaction file not found");
        } catch (IOException e) {
            logger.error(e.getClass() + "\t" + e.getMessage());

        }
        return transactionPath;
    }

    public void writeDepositFile(Path stockpath, List<String> stockdata) {
        synchronized (PaymentInfo.class) {

            StockFileVO.toString(stockpath, stockdata);

        }
    }

    public void writeTransactionFile(String transactiondata) {
        synchronized (PaymentInfo.class) {
            Path transactionPath = createTransactionFile();
            TransactionFileVO.toString(transactionPath, transactiondata);

        }
    }


}
