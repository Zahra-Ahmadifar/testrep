package model.service;

import model.entity.PaymentInfo;
import org.apache.log4j.Logger;

import java.math.BigDecimal;
import java.nio.file.Path;
import java.util.List;

/**
 * Created by Asus on 2/24/2021.
 */
public class PaymentOperation implements Runnable {
    private String threadName;
    BigDecimal totalAmount;
    String debtorDepositNumber = "";
    List<PaymentInfo> paymentList;
    List<PaymentInfo> stocktList;
    static Logger logger = Logger.getLogger(PaymentOperation.class);
    Path stockpath;
    Path transactionPath;
    List<String> stockdata;
    FileManage file = new FileManage();


    public PaymentOperation(List<String> stockdata, List<PaymentInfo> paymentListPerThread, BigDecimal totalAmount, String debtorDepositNumber, List<PaymentInfo> stocktList,
                            Path stockpath) {
        this.stockdata = stockdata;
        this.paymentList = paymentListPerThread;
        this.totalAmount = totalAmount;
        this.debtorDepositNumber = debtorDepositNumber;
        this.stocktList = stocktList;
        this.stockpath = stockpath;

    }

    public void run() {
        threadName = Thread.currentThread().getName();
        synchronized (PaymentInfo.class) {

            for (int index = 0; index < paymentList.size(); index++) {

                PaymentInfo payment = paymentList.get(index);

                if (!(paymentList.get(index).depositType)) {
                    String transactioData = debtorDepositNumber + "\t" + payment.getDepositNumber() + "\t" + payment.getAmount();
                    logger.info(threadName);
                    if (stocktList.size() > 1) {
                        find(payment);
                    }
                    depositOfCreditor(payment);
                    file.writeDepositFile(stockpath, stockdata);
                    file.writeTransactionFile(transactioData);

                } else if (paymentList.get(index).depositType) {
                    logger.info(threadName);
                    if (stocktList.size() > 1) {
                        payment = stocktList.get(index);
                    }
                    depositOfDebtor(payment);
                    file.writeDepositFile(stockpath, stockdata);

                }
            }

        }
    }

    private BigDecimal minus(BigDecimal a, BigDecimal b) {
        BigDecimal answer = a.subtract(b);
        return answer;

    }

    private BigDecimal sum(BigDecimal a, BigDecimal b) {
        BigDecimal answer = a.add(b);
        return answer;
    }

    private String returnStockData(PaymentInfo payment) {
        String depositNumber = payment.getDepositNumber();
        BigDecimal depositAmount = payment.getAmount();
        String depositData = depositNumber + "\t" + depositAmount;
        return depositData;
    }

    private void depositOfDebtor(PaymentInfo payment) {
        BigDecimal b1 = payment.getAmount();
        BigDecimal temp = minus(b1, totalAmount);
        payment.setAmount(temp);
        String depositData = returnStockData(payment);
        stockdata.add(depositData);
    }

    private void depositOfCreditor(PaymentInfo payment) {
        String depositData = returnStockData(payment);
        stockdata.add(depositData);
    }

    private void find(PaymentInfo payment) {
        for (int j = 0; j < stocktList.size(); j++) {
            if (payment.getDepositNumber().equals(stocktList.get(j).getDepositNumber())) {
                BigDecimal b = stocktList.get(j).getAmount();
                payment.setAmount(sum(payment.getAmount(), b));
            }
        }


    }

}
