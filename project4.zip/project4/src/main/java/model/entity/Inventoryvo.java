package model.entity;

import exceptionhandling.FialFileWritingException;

import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Path;
import java.util.List;

/**
 * Created by Asus on 2/27/2021.
 */
public class Inventoryvo {
    Path value;
    private String depositNumber;
    private BigDecimal amount;


    public String getDepositNumber() {
        return depositNumber;
    }

    public void setDepositNumber(String depositNumber) {
        this.depositNumber = depositNumber;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public static void writeToFile(Path stockpath, List<String> stockdata) {
        try {
            FileWriter writer = new FileWriter(String.valueOf(stockpath));
            for (String str : stockdata) {
                writer.write(str + System.lineSeparator());
            }
            writer.close();
        } catch (IOException e) {
            throw new FialFileWritingException("fail writing into inventory file.");
        }
    }
}
