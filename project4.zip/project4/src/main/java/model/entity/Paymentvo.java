package model.entity;

import exceptionhandling.FialFileWritingException;

import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;

/**
 * Created by Asus on 2/27/2021.
 */
public class Paymentvo {
    Path value;
    public boolean depositType = true;
    private String depositNumber;
    private BigDecimal amount;


    public String getDepositNumber() {
        return depositNumber;
    }

    public void setDepositNumber(String depositNumber) {
        this.depositNumber = depositNumber;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }


    public static void writeToFile(Path paymentPath, String debtor, String[] staffs, int employeenum) {
        try {
            Files.write(paymentPath, debtor.getBytes(), StandardOpenOption.APPEND);
            Files.write(paymentPath, System.getProperty("line.separator").getBytes(), StandardOpenOption.APPEND);

            for (int i = 0; i < employeenum; i++) {
                Files.write(paymentPath, staffs[i].getBytes(), StandardOpenOption.APPEND);
                Files.write(paymentPath, System.getProperty("line.separator").getBytes(), StandardOpenOption.APPEND);
            }
        } catch (IOException e) {
            throw new FialFileWritingException("fail writing into payment file.");
        }

    }
}
