package model.entity;

import exceptionhandling.FialFileWritingException;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;

/**
 * Created by Asus on 2/27/2021.
 */
public class Transactionvo {
    Path value;

    public static void writeToFile(Path transactionPath, String transactiondata) {
        try {

            Files.write(transactionPath, transactiondata.getBytes(), StandardOpenOption.APPEND);
            Files.write(transactionPath, System.getProperty("line.separator").getBytes(), StandardOpenOption.APPEND);


        } catch (IOException e) {
            throw new FialFileWritingException("fail writing into transaction file.");
        }

    }

}
