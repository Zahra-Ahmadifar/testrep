package model.entity;

import java.math.BigDecimal;

/**
 * Created by Asus on 2/16/2021.
 */
public class PaymentInfo {
    public boolean depositType = true;
    private String depositNumber;
    private BigDecimal amount;


    public String getDepositNumber() {
        return depositNumber;
    }

    public void setDepositNumber(String depositNumber) {
        this.depositNumber = depositNumber;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }
}
