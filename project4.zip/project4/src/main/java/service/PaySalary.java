package service;

import exceptionhandling.FialFileWritingException;
import exceptionhandling.NonenoughInventoryException;
import model.entity.Inventoryvo;
import model.entity.Paymentvo;
import org.apache.log4j.Logger;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Created by Asus on 2/16/2021.
 */
public class PaySalary {
    private String debtorDepositNumber;
    List<Paymentvo> paymentList = new ArrayList<>();
    ExecutorService executor = Executors.newFixedThreadPool(7);
    BigDecimal debtAmount = BigDecimal.ZERO;
    BigDecimal totalAmount = BigDecimal.ZERO;
    private int threadNumber;
    private int recordNumberPerThread = 143;
    List<Inventoryvo> inventoryList = new ArrayList<>();
    List<String> inventorydata = new ArrayList<>();


    private Path paymentPath;
    private Path inventoryPath;

    static Logger logger = Logger.getLogger(PaySalary.class);

    FileManage file = new FileManage();


    public void pay() {
        try {
            file.createPaymentFile();
            paymentPath = Paths.get("PaymentFiles/PaymentFile.txt");
            file.createInventoryFile();
            inventoryPath = Paths.get("PaymentFiles/InventoryFile.txt");

        } catch (FileNotFoundException e) {
            logger.error("payment file not found");
        } catch (IOException e) {
            System.out.println(e.getClass() + "\t" + e.getMessage());
        }

        paymentList = createPaymentlist();

        inventoryList = createInventoryList();

        if (checkDebtorInventoty())
            doPayment();
        else
            throw new NonenoughInventoryException("debtor amount isnt enough");

    }


    private List createInventoryList() {

        List<String> paymentData;
        try {
            paymentData = readFile(inventoryPath);
        } catch (IOException e) {
            throw new FialFileWritingException("fail reading file");
        }
        for (String src : paymentData) {
            Inventoryvo payment = new Inventoryvo();
            String[] data = src.split("\t");
            payment.setDepositNumber(data[0]);
            payment.setAmount(new BigDecimal(data[1]));
            inventoryList.add(payment);
        }
        return inventoryList;
    }

    private List createPaymentlist() {

        List<String> paymentData;
        try {
            paymentData = readFile(paymentPath);
        } catch (IOException e) {
            throw new FialFileWritingException("fail reading file");
        }

        for (String payments : paymentData) {
            Paymentvo payment = new Paymentvo();
            String[] data = payments.split("\t");
            if (!data[0].equals("debtor")) {
                payment.setDebtor(false);
            } else payment.setDebtor(true);
            payment.setDepositNumber(data[1]);
            payment.setAmount(new BigDecimal(data[2]));

            calculateTotalamount(payment);
            paymentList.add(payment);
        }
        return paymentList;


    }

    private List readFile(Path filePath) throws IOException {
        List<String> paymentData;
        paymentData = Files.readAllLines(filePath);
        return paymentData;
    }

    private Boolean checkDebtorInventoty() {

        Boolean isEnough = false;
        BigDecimal debtorlastAmount = inventoryList.get(0).getAmount();
        if (!(debtorlastAmount.compareTo(totalAmount) < 0)) {
            isEnough = true;
        }

        return isEnough;

    }


    private void doPayment() {

        int fromIndex = 0;
        int totalPaymentRecord = paymentList.size();
        threadNumber = totalPaymentRecord / recordNumberPerThread;

        for (int i = 0; i < threadNumber; i++) {
            int toIndex = fromIndex + (recordNumberPerThread);
            List<Paymentvo> paymentListPerThread = new ArrayList<>(paymentList.subList(fromIndex, toIndex));
            List<Inventoryvo> depositList = new ArrayList<>(inventoryList);
            fromIndex += recordNumberPerThread;
            Runnable runnable = new PaymentOperation(inventorydata, paymentListPerThread, totalAmount, debtorDepositNumber, depositList, inventoryPath);
            executor.execute(runnable);
        }
        executor.shutdown();


    }


    private void calculateTotalamount(Paymentvo payment) {
        if (!payment.isDebtor()) {
            totalAmount = totalAmount.add(payment.getAmount());
        } else {
            debtAmount = debtAmount.add(payment.getAmount());
            debtorDepositNumber = payment.getDepositNumber();
        }
    }


}