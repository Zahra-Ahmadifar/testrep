package service;

import model.entity.Inventoryvo;
import model.entity.Paymentvo;
import org.apache.log4j.Logger;

import java.math.BigDecimal;
import java.nio.file.Path;
import java.util.List;

/**
 * Created by Asus on 2/24/2021.
 */
public class PaymentOperation implements Runnable {
    private String threadName;
    BigDecimal totalAmount;
    String debtorDepositNumber = "";
    List<Paymentvo> paymentList;
    List<Inventoryvo> inventoryList;
    static Logger logger = Logger.getLogger(PaymentOperation.class);
    Path inventorypath;
    List<String> Inventorydata;
    FileManage file = new FileManage();


    public PaymentOperation(List<String> inventorydata, List<Paymentvo> paymentListPerThread, BigDecimal totalAmount, String debtorDepositNumber, List<Inventoryvo> inventoryList,
                            Path inventorypath) {
        this.Inventorydata = inventorydata;
        this.paymentList = paymentListPerThread;
        this.totalAmount = totalAmount;
        this.debtorDepositNumber = debtorDepositNumber;
        this.inventoryList = inventoryList;
        this.inventorypath = inventorypath;

    }

    public void run() {
        threadName = Thread.currentThread().getName();
        synchronized (Paymentvo.class) {


            for (int index = 0; index < paymentList.size(); index++) {

                Paymentvo payment = paymentList.get(index);


                if (!(paymentList.get(index).depositType)) {

                    String transactioData = debtorDepositNumber + "\t" + payment.getDepositNumber() + "\t" + payment.getAmount();

                    if (inventoryList.size() > 1) {
                        increaseInventory(payment);
                    }
                    depositOfCreditor(payment);
                    file.writeInventoryFile(inventorypath, Inventorydata);

                    file.writeTransactionFile(transactioData);

                }

                if (paymentList.get(index).depositType) {
                    if (inventoryList.size() > 1) {
                        Inventoryvo inventory = inventoryList.get(index);
                        payment.setAmount(inventory.getAmount());
                    }
                    depositOfDebtor(payment);
                    file.writeInventoryFile(inventorypath, Inventorydata);

                }

            }
        }
    }


    private String returnInventoryData(Paymentvo payment) {
        String depositNumber = payment.getDepositNumber();
        BigDecimal depositAmount = payment.getAmount();
        String depositData = depositNumber + "\t" + depositAmount;
        return depositData;
    }

    private void depositOfDebtor(Paymentvo payment) {
        BigDecimal b1 = payment.getAmount();
        BigDecimal temp = b1.subtract(totalAmount);
        payment.setAmount(temp);
        String depositData = returnInventoryData(payment);
        Inventorydata.add(depositData);

    }

    private void depositOfCreditor(Paymentvo payment) {
        String depositData = returnInventoryData(payment);
        Inventorydata.add(depositData);
    }

    private void increaseInventory(Paymentvo payment) {
        for (int j = 0; j < inventoryList.size(); j++) {
            if (payment.getDepositNumber().equals(inventoryList.get(j).getDepositNumber())) {
                BigDecimal b = inventoryList.get(j).getAmount();
                payment.setAmount(payment.getAmount().add(b));
            }
        }


    }


}
