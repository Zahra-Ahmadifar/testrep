package service;

/**
 * Created by Asus on 2/16/2021.
 */


import model.entity.Inventoryvo;
import model.entity.Paymentvo;
import model.entity.Transactionvo;
import org.apache.log4j.Logger;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.List;

public class FileManage {
    private static String debtorDepositNumber = "1.10.100.1";
    private static String debtorAmount = "99000";
    private static int employeenum = 1000;
    private String creditorAmount = String.valueOf(Integer.parseInt(debtorAmount) / employeenum);


    static Logger logger = Logger.getLogger(FileManage.class);

    public Path createPaymentFile() {

        String debtor = "debtor\t" + debtorDepositNumber + "\t" + debtorAmount;

        String[] staffs = new String[employeenum];
        for (int i = 0; i < employeenum; i++) {

            String staffDepositNumber = String.format("1.20.100.%d ", i + 1);

            staffs[i] = "creditor\t" + staffDepositNumber + "\t" + creditorAmount;
        }
        Path paymentPath = Paths.get("PaymentFiles/PaymentFile.txt");
        try {

            if (!Files.exists(paymentPath)) {

                Files.createFile(paymentPath);
                Paymentvo.writeToFile(paymentPath, debtor, staffs, employeenum);


            } else {
                logger.info("payment file already exists.");
            }

        } catch (FileNotFoundException e) {
            logger.error("payment file not found");
        } catch (IOException e) {
            System.out.println(e.getClass() + "\t" + e.getMessage());
        }
        return paymentPath;
    }

    public Path createInventoryFile() {

        Path inventoryPath = Paths.get("PaymentFiles/InventoryFile.txt");
        try {

            if (!Files.exists(inventoryPath)) {

                Files.createFile(inventoryPath);
                String bank = debtorDepositNumber + "\t" + debtorAmount;
                Files.write(inventoryPath, bank.getBytes(), StandardOpenOption.APPEND);
                Files.write(inventoryPath, System.getProperty("line.separator").getBytes(), StandardOpenOption.APPEND);

            } else {
                logger.info("Inventory file already exists.");
            }

        } catch (FileNotFoundException e) {
            logger.error("inventory file not found");
        } catch (IOException e) {
            logger.error(e.getClass() + "\t" + e.getMessage());

        }
        return inventoryPath;
    }

    public Path createTransactionFile() {

        Path transactionPath = Paths.get("PaymentFiles/TransactionFile.txt");
        try {

            if (!Files.exists(transactionPath)) {

                Files.createFile(transactionPath);
            } else {
                logger.info("transaction file updating.");
            }

        } catch (FileNotFoundException e) {
            logger.error("transaction file not found");
        } catch (IOException e) {
            logger.error(e.getClass() + "\t" + e.getMessage());

        }
        return transactionPath;
    }

    public void writeInventoryFile(Path inventorypath, List<String> inventorydata) {
        synchronized (Paymentvo.class) {

            Inventoryvo.writeToFile(inventorypath, inventorydata);

        }
    }

    public void writeTransactionFile(String transactiondata) {
        synchronized (Paymentvo.class) {

            Path transactionPath = createTransactionFile();
            Transactionvo.writeToFile(transactionPath, transactiondata);

        }
    }


}
