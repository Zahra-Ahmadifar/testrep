package FilesVO;

import exceptionhandling.FialFileWritingException;

import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Path;
import java.util.List;

/**
 * Created by Asus on 2/27/2021.
 */
public class StockFileVO {
    Path value;

    public static void toString(Path stockpath, List<String> stockdata) {
        try {
            FileWriter writer = new FileWriter(String.valueOf(stockpath));
            for (String str : stockdata) {
                writer.write(str + System.lineSeparator());
            }
            writer.close();
        } catch (IOException e) {
            throw new FialFileWritingException("fail writing into stock file.");
        }
    }
}
