package FilesVO;

import exceptionhandling.FialFileWritingException;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;

/**
 * Created by Asus on 2/27/2021.
 */
public class PaymentFileVO {
    Path value;

    public static void toString(Path paymentPath, String debtor, String[] staffs, int employeenum) {
        try {
            Files.write(paymentPath, debtor.getBytes(), StandardOpenOption.APPEND);
            Files.write(paymentPath, System.getProperty("line.separator").getBytes(), StandardOpenOption.APPEND);

            for (int i = 0; i < employeenum; i++) {
                Files.write(paymentPath, staffs[i].getBytes(), StandardOpenOption.APPEND);
                Files.write(paymentPath, System.getProperty("line.separator").getBytes(), StandardOpenOption.APPEND);
            }
        } catch (IOException e) {
            throw new FialFileWritingException("fail writing into transaction file.");
        }

    }
}
