package main;

import exceptionhandling.FialFileWritingException;
import common.PaySalary;

public class Main {

    public static void main(String[] args) throws FialFileWritingException, InterruptedException {

        PaySalary p = new PaySalary();
        p.pay();


    }
}
