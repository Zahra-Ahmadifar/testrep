package main;

import exceptionhandling.FialFileWritingException;
import service.PaySalary;

public class Main {

    public static void main(String[] args) throws FialFileWritingException, InterruptedException {

        PaySalary p = new PaySalary();
        p.pay();


    }
}
