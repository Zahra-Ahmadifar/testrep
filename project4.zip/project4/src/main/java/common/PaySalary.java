package common;

import exceptionhandling.FialFileWritingException;
import org.apache.log4j.Logger;

import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Created by Asus on 2/16/2021.
 */
public class PaySalary {
    private String debtorDepositNumber;
    private int totalPaymentRecord;
    List<PaymentInfo> paymentList = new ArrayList<>();
    ExecutorService executor = Executors.newFixedThreadPool(5);
    BigDecimal debtAmount = BigDecimal.ZERO;
    BigDecimal totalAmount = BigDecimal.ZERO;
    private int threadNumber;
    private int recordNumberPerThread = 25;
    List<PaymentInfo> stockList = new ArrayList<>();
    List<String> stockdata = new ArrayList<>();


    private Path paymentPath;
    private Path stockPath;
    private Path transactionPath;

    static Logger logger = Logger.getLogger(PaySalary.class);
    FileManage file = new FileManage();


    public void pay() {

        paymentPath = file.createPaymentFile();
        stockPath = file.createStockFile();
        transactionPath = file.createTransactionFile();

        createPaymentlist();

    }

    private void createPaymentlist() {

        List<String> paymentData;
        try {
            paymentData = Files.readAllLines(paymentPath);
        } catch (IOException e) {
            throw new FialFileWritingException("fail reading the payment value file.");
        }
        for (String payments : paymentData) {
            PaymentInfo payment = new PaymentInfo();
            String[] data = payments.split("\t");
            if (!data[0].equals("debtor")) {
                payment.debtor = false;
            }
            payment.setDepositNumber(data[1]);
            payment.setAmount(data[2]);
            if (!payment.debtor) {
                totalAmount = totalAmount.add(new BigDecimal(payment.getAmount()));
            } else {
                BigDecimal b1 = new BigDecimal(payment.getAmount());
                debtAmount = debtAmount.add(b1);
                debtorDepositNumber = payment.getDepositNumber();
            }
            paymentList.add(payment);
        }

        totalPaymentRecord = paymentList.size();
        doPayment();

    }

    private void doPayment() {
        int fromIndex = 0;
        threadNumber = totalPaymentRecord / recordNumberPerThread;
        if (checkStockfile()) {
            for (int i = 0; i < threadNumber; i++) {
                int toIndex = fromIndex + (recordNumberPerThread);
                List<PaymentInfo> paymentListPerThread = new ArrayList<>(paymentList.subList(fromIndex, toIndex));
                fromIndex += recordNumberPerThread;
                Runnable runnable = new PaymentOperation(stockdata, paymentListPerThread, totalAmount, debtorDepositNumber, stockList, stockPath, transactionPath);
                executor.execute(runnable);

            }
            executor.shutdown();
        } else {
            logger.info("debtor amount is not enough for payment");
        }
    }

    private boolean checkStockfile() {
        boolean canpay = false;
        List<String> paymentData = new ArrayList();
        try {
            paymentData = Files.readAllLines(stockPath);
        } catch (IOException e) {
            throw new FialFileWritingException("fail reading the stock value file.");
        }
        for (String src : paymentData) {
            PaymentInfo payment = new PaymentInfo();
            String[] data = src.split("\t");
            payment.setDepositNumber(data[0]);
            payment.setAmount(data[1]);
            BigDecimal debtorlastAmount = new BigDecimal(data[1]);
            if (debtorlastAmount.compareTo(totalAmount) != -1)
                canpay = true;
            stockList.add(payment);
        }
        return canpay;
    }
}