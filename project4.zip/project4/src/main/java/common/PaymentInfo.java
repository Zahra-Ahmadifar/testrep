package common;

/**
 * Created by Asus on 2/16/2021.
 */
public class PaymentInfo {

    public boolean debtor=true;
    private String depositNumber;
    private String amount;


    public String getDepositNumber() {
        return depositNumber;
    }

    public void setDepositNumber(String depositNumber) {
        this.depositNumber = depositNumber;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }
}
