package common;

import org.apache.log4j.Logger;

import java.math.BigDecimal;
import java.nio.file.Path;
import java.util.List;

/**
 * Created by Asus on 2/24/2021.
 */
public class PaymentOperation implements Runnable {
    private String threadName;
    BigDecimal totalAmount;
    String debtorDepositNumber = "";
    List<PaymentInfo> paymentList;
    List<PaymentInfo> stocktList;
    static Logger logger = Logger.getLogger(PaymentOperation.class);
    Path stockpath;
    Path transactionPath;
    List<String> stockdata;
    FileManage file = new FileManage();


    public PaymentOperation(List<String> stockdata, List<PaymentInfo> paymentListPerThread, BigDecimal totalAmount, String debtorDepositNumber, List<PaymentInfo> stocktList,
                            Path stockpath, Path transactionpath) {
        this.stockdata = stockdata;
        this.paymentList = paymentListPerThread;
        this.totalAmount = totalAmount;
        this.debtorDepositNumber = debtorDepositNumber;
        this.stocktList = stocktList;
        this.stockpath = stockpath;
        this.transactionPath = transactionpath;
    }

    public void run() {

        threadName = Thread.currentThread().getName();

        synchronized (PaymentInfo.class) {

            for (int paymentIndex = 0; paymentIndex < paymentList.size(); paymentIndex++) {

                if (!(paymentList.get(paymentIndex).debtor)) {
                    logger.info(threadName);
                    String transactioData = debtorDepositNumber + "\t" + paymentList.get(paymentIndex).getDepositNumber() + "\t" + paymentList.get(paymentIndex).getAmount();
                    if (stocktList.size() > 1) {
                        for (int i = 0; i < stocktList.size(); i++) {
                            if (paymentList.get(paymentIndex).getDepositNumber() == stocktList.get(i).getDepositNumber()) {
                                BigDecimal sum = (new BigDecimal(paymentList.get(paymentIndex).getAmount())).add(new BigDecimal(stocktList.get(i).getDepositNumber()));
                                String depositData = paymentList.get(paymentIndex).getDepositNumber() + "\t" + String.valueOf(sum);
                                stockdata.add(depositData);
                            }
                        }
                    } else {

                        String depositData = paymentList.get(paymentIndex).getDepositNumber() + "\t" + paymentList.get(paymentIndex).getAmount() + "\t";
                        stockdata.add(depositData);
                    }

                    file.writeDepositFile(stockpath, stockdata);
                    file.writeTransactionFile(transactionPath, transactioData);


                } else if (paymentList.get(paymentIndex).debtor) {
                    logger.info(threadName);
                    BigDecimal b1 = new BigDecimal(paymentList.get(paymentIndex).getAmount());
                    BigDecimal temp = b1.subtract(totalAmount);
                    paymentList.get(paymentIndex).setAmount(String.valueOf(temp));
                    String depositData = paymentList.get(paymentIndex).getDepositNumber() + "\t" + paymentList.get(paymentIndex).getAmount() + "\t";
                    stockdata.add(depositData);

                    file.writeDepositFile(stockpath, stockdata);

                }
            }
        }


    }

}
