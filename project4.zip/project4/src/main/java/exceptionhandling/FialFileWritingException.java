package exceptionhandling;

/**
 * Created by Asus on 2/24/2021.
 */
public class FialFileWritingException extends RuntimeException {
    public FialFileWritingException() {
    }

    public FialFileWritingException(String message) {
        super(message);
    }
}
