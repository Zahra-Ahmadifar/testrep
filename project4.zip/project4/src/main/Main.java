package main;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner userInput = new Scanner(System.in);
        PaySalary p = new PaySalary();
        p.pay();


    }
}
