package service;

import model.entity.Inventoryvo;
import model.entity.Paymentvo;
import model.entity.Transactionvo;

import java.math.BigDecimal;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Asus on 2/24/2021.
 */
public class PaymentOperation implements Runnable {

    String debtorDepositNumber = "";
    List<Paymentvo> paymentList;
    List<Inventoryvo> inventoryList;
    Path inventorypath;
    List<String> Inventorydata = new ArrayList<>();

    public PaymentOperation(List<Paymentvo> paymentListPerThread, String debtorDepositNumber, List<Inventoryvo> inventoryList, Path inventorypath) {
        this.paymentList = paymentListPerThread;
        this.debtorDepositNumber = debtorDepositNumber;
        this.inventoryList = inventoryList;
        this.inventorypath = inventorypath;

    }

    public void run() {
        String threadName = Thread.currentThread().getName();
        FileManage file = new FileManage();
        synchronized (Paymentvo.class) {
            Inventoryvo inventory = inventoryList.get(0);

            for (int index = 0; index < paymentList.size(); index++) {
                Paymentvo payment = paymentList.get(index);

                if (!(payment.isDebtor())) {
                    String transactioData = transactionData(payment);
                    withdraw(inventory, payment.getAmount());
                    deposit(payment);
                    file.updateInventoryFile(inventorypath, Inventorydata);
                    file.updateTransactionFile(transactioData);
                }
            }
        }
    }

    private void withdraw(Inventoryvo inventoryvo, BigDecimal creditoramount) {
        BigDecimal debtorInventory = inventoryvo.getAmount();
        BigDecimal temp = debtorInventory.subtract(creditoramount);
        inventoryvo.setAmount(temp);
        String depositData = inventoryvo.toString();
        Inventorydata.add(depositData);
    }

    private void deposit(Paymentvo payment) {
        if (inventoryList.size() > 1) {
            increaseInventory(payment);
        } else {
            Inventoryvo inventoryvo = new Inventoryvo();
            inventoryvo.setDepositNumber(payment.getDepositNumber());
            inventoryvo.setAmount(payment.getAmount());
            String depositData = inventoryvo.toString();
            Inventorydata.add(depositData);
        }
    }

    private void increaseInventory(Paymentvo payment) {
        for (int j = 0; j < inventoryList.size(); j++) {
            if (payment.getDepositNumber().equals(inventoryList.get(j).getDepositNumber())) {
                BigDecimal creditorInventory = inventoryList.get(j).getAmount();
                inventoryList.get(j).setAmount(payment.getAmount().add(creditorInventory));
                String depositData = inventoryList.get(j).toString();
                Inventorydata.add(depositData);
            }
        }
    }

    private String transactionData(Paymentvo payment) {
        Transactionvo transactionvo = new Transactionvo();
        transactionvo.setDebtorDepositNumber(debtorDepositNumber);
        transactionvo.setCreditorDepositNumber(payment.getDepositNumber());
        transactionvo.setAmount(payment.getAmount());
        return transactionvo.toString();
    }

}
