package service;

/**
 * Created by Asus on 2/16/2021.
 */


import exceptionhandling.FialFileWritingException;
import model.entity.Paymentvo;
import org.apache.log4j.Logger;

import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.List;
import java.util.Random;

public class FileManage {
    private static String debtorDepositNumber = "1.10.100.1";
    private static String debtorAmount = "99000";
    private static int employeenum = 1000;
    static Logger logger = Logger.getLogger(FileManage.class);

    public void createPaymentFile() throws IOException, FileNotFoundException {
        Random generator = new Random(0);
        Paymentvo paymentvo = new Paymentvo();

        String debtor = "debtor\t" + debtorDepositNumber + "\t" + debtorAmount;

        String[] staffs = new String[employeenum];
        for (int i = 0; i < employeenum; i++) {
            String creditorAmount = String.valueOf(generator.nextInt(100) + 10);
            paymentvo.setDepositNumber(String.format("1.20.100.%d ", i + 1));
            paymentvo.setAmount(new BigDecimal(creditorAmount));

            staffs[i] = "creditor\t" + paymentvo.toString();
        }
        Path paymentPath = Paths.get("PaymentFiles/PaymentFile.txt");

        if (!Files.exists(paymentPath)) {

            Files.createFile(paymentPath);
            writeToPaymentFile(paymentPath, debtor, staffs, employeenum);

        } else {
            logger.info("payment file already exists.");
        }
    }

    public void createInventoryFile() throws IOException, FileNotFoundException {

        Path inventoryPath = Paths.get("PaymentFiles/InventoryFile.txt");

        if (!Files.exists(inventoryPath)) {

            Files.createFile(inventoryPath);
            String bank = debtorDepositNumber + "\t" + debtorAmount;
            Files.write(inventoryPath, bank.getBytes(), StandardOpenOption.APPEND);
            Files.write(inventoryPath, System.getProperty("line.separator").getBytes(), StandardOpenOption.APPEND);

        } else {
            logger.info("Inventory file already exists.");
        }
    }

    public void createTransactionFile() throws IOException, FileNotFoundException {

        Path transactionPath = Paths.get("PaymentFiles/TransactionFile.txt");

        if (!Files.exists(transactionPath)) {

            Files.createFile(transactionPath);
        } else {
            logger.info("transaction file updating.");
        }
    }

    public void updateInventoryFile(Path inventorypath, List<String> inventorydata) {
        synchronized (Paymentvo.class) {
            try {
                writeToInventoryFile(inventorypath, inventorydata);
            } catch (IOException e) {
                throw new FialFileWritingException("fail writing into inventory file.");
            }
        }
    }

    public void updateTransactionFile(String transactiondata) {
        synchronized (Paymentvo.class) {
            try {
                createTransactionFile();
                Path transactionPath = Paths.get("PaymentFiles/TransactionFile.txt");
                writeToTransactionFile(transactionPath, transactiondata);
            } catch (FileNotFoundException e) {
                logger.error("transaction file not found");

            } catch (IOException e) {
                throw new FialFileWritingException("fail writing into transaction file.");
            }
        }
    }

    public static void writeToPaymentFile(Path paymentPath, String debtor, String[] staffs, int employeenum) throws IOException {

        Files.write(paymentPath, debtor.getBytes(), StandardOpenOption.APPEND);
        Files.write(paymentPath, System.getProperty("line.separator").getBytes(), StandardOpenOption.APPEND);

        for (int i = 0; i < employeenum; i++) {
            Files.write(paymentPath, staffs[i].getBytes(), StandardOpenOption.APPEND);
            Files.write(paymentPath, System.getProperty("line.separator").getBytes(), StandardOpenOption.APPEND);
        }
    }

    public static void writeToTransactionFile(Path transactionPath, String transactiondata) throws IOException {

        Files.write(transactionPath, transactiondata.getBytes(), StandardOpenOption.APPEND);
        Files.write(transactionPath, System.getProperty("line.separator").getBytes(), StandardOpenOption.APPEND);
    }

    public static void writeToInventoryFile(Path stockpath, List<String> stockdata) throws IOException {

        FileWriter writer = new FileWriter(String.valueOf(stockpath), true);
        for (String str : stockdata) {
            writer.write(str + System.lineSeparator());
        }
        writer.close();

    }
}
