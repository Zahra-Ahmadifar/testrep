package entity;

import java.time.LocalDate;

/**
 * Created by Asus on 4/7/2021.
 */
public class EmployeeLeave {
    private int employeeId;
    private LocalDate startDate;
    private LocalDate endDate;
    private String typeofleave;

    public int getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(int employeeId) {
        this.employeeId = employeeId;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    public String getTypeofleave() {
        return typeofleave;
    }

    public void setTypeofleave(String typeofleave) {
        this.typeofleave = typeofleave;
    }

}