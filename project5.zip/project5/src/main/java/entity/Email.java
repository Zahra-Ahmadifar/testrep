package entity;

import java.util.HashSet;
import java.util.Set;

/**
 * Created by Asus on 4/7/2021.
 */
public class Email {
    private String sender;
    private Set<String> receiverEmployees = new HashSet<String>();
    private String emailSubject;
    private String emailBody;
    private String filePath;

    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public Set<String> getReceiverEmployees() {
        return receiverEmployees;
    }

    public void setReceiverEmployees(Set<String> receiverEmployees) {
        this.receiverEmployees = receiverEmployees;
    }

    public String getEmailSubject() {
        return emailSubject;
    }

    public void setEmailSubject(String emailSubject) {
        this.emailSubject = emailSubject;
    }

    public String getEmailBody() {
        return emailBody;
    }

    public void setEmailBody(String emailBody) {
        this.emailBody = emailBody;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }
}
