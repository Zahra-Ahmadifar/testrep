package model.entity;

import javax.persistence.*;
import javax.persistence.Entity;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by Asus on 4/7/2021.
 */
@Entity
@Table(name = "t_employee")
public class Employee extends model.entity.Entity {

    @Column(name = "c_firstName", columnDefinition = "VARCHAR(255)")
    private String name;

    @Column(name = "c_lastName", columnDefinition = "VARCHAR(255)")
    private String lastName;

    @Column(name = "c_fatherName", columnDefinition = "VARCHAR(255)")
    private String fatherName;

    @ManyToOne()
    @JoinColumn(name = "c_position")
    private CategoryElement position;

    @Column(name = "c_email", columnDefinition = "VARCHAR(255)")
    private String email;

    @Column(name = "c_manager", columnDefinition = "VARCHAR(255)")
    private String manager;

    @OneToMany(mappedBy = "employee")
    private Set<Email> sentEmails = new HashSet<Email>();

    public Employee(String name, String lastName, String fatherName, CategoryElement position, String email, String manager) {
        this.name = name;
        this.lastName = lastName;
        this.fatherName = fatherName;
        this.position = position;
        this.email = email;
        this.manager = manager;
    }

    public Employee() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getFatherName() {
        return fatherName;
    }

    public void setFatherName(String fatherName) {
        this.fatherName = fatherName;
    }

    public CategoryElement getPosition() {
        return position;
    }

    public void setPosition(CategoryElement position) {
        this.position = position;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getManager() {
        return manager;
    }

    public void setManager(String manager) {
        this.manager = manager;
    }

    public Set<Email> getSentEmails() {
        return sentEmails;
    }

    public void setSentEmails(Set<Email> sentEmails) {
        this.sentEmails = sentEmails;
    }


}
