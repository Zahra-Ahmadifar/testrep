package model.entity;

import javax.persistence.*;
import javax.persistence.Entity;
import java.time.LocalDate;

/**
 * Created by Asus on 4/7/2021.
 */
@Entity
@Table(name = "t_employeeleave")
public class EmployeeLeave extends model.entity.Entity {

    @Column(name = "c_startDate", columnDefinition = "DATE")
    private LocalDate startDate;

    @Column(name = "c_endDate", columnDefinition = "DATE")
    private LocalDate endDate;

    @ManyToOne()
    @JoinColumn(name = "c_leaveStatus")
    private CategoryElement leaveStatus;

    public EmployeeLeave(LocalDate startDate, LocalDate endDate, CategoryElement leaveStatus) {
        this.startDate = startDate;
        this.endDate = endDate;
        this.leaveStatus = leaveStatus;

    }

    public EmployeeLeave() {

    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    public CategoryElement getLeaveStatus() {
        return leaveStatus;
    }

    public void setLeaveStatus(CategoryElement leaveStatus) {
        this.leaveStatus = leaveStatus;
    }

}