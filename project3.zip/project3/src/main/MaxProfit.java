package main;

/**
 * Created by Asus on 2/14/2021.
 */
public class MaxProfit {


    public int calculateprofit(int[] stockprice){
        int max=0;
        int diffrence=0;
        for (int i = 0; i <stockprice.length ; i++) {
            for (int j = i+1; j <stockprice.length ; j++) {
                diffrence=stockprice[j]-stockprice[i];
                if (diffrence>max){
                    max=diffrence;
                }
            }

        }


        return max;


    }
}
