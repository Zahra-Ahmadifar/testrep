package exceptionhandling;

/**
 * Created by Asus on 3/7/2021.
 */
public class NonenoughInventoryException extends RuntimeException {

    public NonenoughInventoryException() {
    }

    public NonenoughInventoryException(String message) {
        super(message);
    }
}
