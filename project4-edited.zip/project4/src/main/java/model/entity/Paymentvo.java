package model.entity;

import java.math.BigDecimal;
import java.nio.file.Path;

/**
 * Created by Asus on 2/27/2021.
 */
public class Paymentvo {
    Path value;

    public boolean debtor;
    private String depositNumber;
    private BigDecimal amount;


    public boolean isDebtor() {
        return debtor;
    }

    public void setDebtor(boolean debtor) {
        this.debtor = debtor;
    }

    public String getDepositNumber() {
        return depositNumber;
    }

    public void setDepositNumber(String depositNumber) {
        this.depositNumber = depositNumber;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    @Override
    public String toString() {
        return depositNumber + "\t" + amount;
    }
}
