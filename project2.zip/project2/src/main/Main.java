package main;



import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        MagicSquare magicSquare = new MagicSquare();
        int[][] inputmatrix=new int[3][3];

        Scanner userinput = new Scanner(System.in);
        for (int r = 0; r <inputmatrix.length ; r++) {

            System.out.print(String.format("plz enter 3 elements of row %d. spilit element with (,) :",r+1));
            String[] element = userinput.nextLine().split(",");
            for (int j = 0; j <element.length ; j++) {
                int x=Integer.parseInt(element[j]);
                if( x<0 | x>10) {
                    System.out.println("plz enter one-digit natural number");
                    System.out.print(String.format("plz enter 3 elements of row %d again. :",r+1));
                     element = userinput.nextLine().split(",");

                }

               else for (int i = 0; i < element.length; i++) {
                    inputmatrix[r][i] = Integer.parseInt(element[i]);
                }
            }


        }

        System.out.println("the Minimum cost to convert this matrix into magic square is :" + magicSquare.findMinimumCost(inputmatrix));
    }
}
