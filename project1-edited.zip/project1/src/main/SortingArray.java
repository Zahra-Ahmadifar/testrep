package main;

import java.util.ArrayList;
import java.util.List;

public class SortingArray {

    int count = 0;

    private void sort(List<Integer> inputlist, int length) {

        for (int i = 0; i < length; i++) {
            for (int j = i + 1; j < length; j++) {
                if (inputlist.get(j) < inputlist.get(i))
                    swap(j, i, inputlist);
            }
        }
    }


    private void swap(int min, int i, List<Integer> inputlist) {
        int temp;
        temp = inputlist.get(min);
        inputlist.set(min, inputlist.get(i));
        inputlist.set(i, temp);

    }


    public int changeNumbers(List<Integer> inputlist,int length){
        List<Integer> firstlist = new ArrayList<Integer>(inputlist);

        sort( inputlist, length);
        for (int i = 0; i < length; i++) {
            if (inputlist.get(i) != firstlist.get(i))
                count++;
        }
        return count;
    }

}
